package com.demo.weatherservice.exception;

public class ThirdPartyApiException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3800185022146842046L;

	
}
