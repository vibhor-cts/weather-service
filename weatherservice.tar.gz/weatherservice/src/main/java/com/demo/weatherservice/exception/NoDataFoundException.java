package com.demo.weatherservice.exception;

public class NoDataFoundException extends Exception {

	
	
}
