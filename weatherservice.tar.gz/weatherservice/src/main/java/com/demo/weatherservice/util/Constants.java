package com.demo.weatherservice.util;

public abstract class Constants {
	
}
