package com.demo.weatherservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
